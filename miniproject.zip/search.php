<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search</title>
    <link rel="stylesheet" href="logreg.css">
</head>
<body>
    <div class="header">
        <h2 class="logo">Grade Master</h2>
        <nav class="navigation">
            <a href="home.html">Home</a>
            <a href="about.html">About Us</a>
            <a href="#">Profile</a>
            <a href="home.html">Sign Up</a>
        </nav>
    </div>
    <div class="log" style="min-height: auto;">
        <div class="txt">
            <h2 style="text-align:center;">Find Report</h2>
        </div>
        <form action="search.php" method="POST">
            <div class="frme">
                <span class="icon"></span>
                <input type="text" name="ktuid" id="ktuid" placeholder="enter register number " required>
            </div>
            <button type="submit" name="submit">Find</button>
        </form>
        <?php
        if(isset($_POST["submit"])){
            $id = $_POST["ktuid"];
            session_start();
            $_SESSION["ktid"]= $id;
            require_once "db.php";
            $sql="SELECT id FROM summary where id='$id'";
            $result=mysqli_query($conn,$sql);
            $rowcount=mysqli_num_rows($result);
            if($rowcount>0){
                header('Location: dash.php');
                exit;
            }
            else{
                echo "<div class='alert alert-danger'  id='danger' style='margin: left 75px;paddinf: left 75px;'>PLEASE ENTER A  VALID ID </div>";
            }
        }
        ?>
    </div>
</body>
</html>
