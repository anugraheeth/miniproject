<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dash Board </title>
    <script src="https://unpkg.com/phosphor-icons"></script>
    <link rel="stylesheet" href="dash.css">
</head>
<body>
    <div class="header">
        <h2 class="logo">Grade Master</h2>
        <nav class="navigation">
            <form method="POST">
                <div class="search">
                    <input type="text" class="search-box" placeholder="Search..." name="search" required>
                    <button class="search-btn" name="find"><i class="ph-magnifying-glass-bold"></i></button>
                </div>
            </form>
            <a href="logout.php">Log Out</a>
        </nav>
    </div>
    <div class="txt">
        <h2 style="text-align: center;">Dash Board</h2>
    </div>
    <div class="container">
        <div class="info">
            <div id="hed"><h3 style="text-align:center"><b>COLLEGE OF ENGINEERING KIDANGOOR</b><h3></div>
            <div class="grid">
                <?php
                    session_start();
                    if (!isset($_SESSION['user_authenticated'])) {
                        header("Location: login.php");
                        exit;
                    }
                    $var1=$_SESSION["ktid"];
                    if(substr($var1,0,3)=="KGR"){
                        require_once "ktu.php";
                    }
                    else{
                        require_once "cusat.php";
                    }
                    $sql="SELECT sem,sgpa,pass FROM (
                        SELECT grade.REG_NO as RegNo,'S1S2' AS sem,grade.S1S2 AS sgpa,result.S1S2 AS pass FROM grade,result where grade.REG_NO='$var1'and result.regno='$var1'
                            UNION
                        SELECT grade.REG_NO as RegNo,'S3' AS sem,grade.S3 AS sgpa,result.S3 AS pass FROM grade,result where grade.REG_NO='$var1'and result.regno='$var1'
                            UNION
                        SELECT grade.REG_NO as RegNo,'S4' AS sem,grade.S4 AS sgpa,result.S4 AS pass FROM grade,result where grade.REG_NO='$var1'and result.regno='$var1'
                            UNION
                        SELECT grade.REG_NO as RegNo,'S5' AS sem,grade.S5 AS sgpa,result.S5 AS pass FROM grade,result where grade.REG_NO='$var1'and result.regno='$var1'
                            UNION
                        SELECT grade.REG_NO as RegNo,'S6' AS sem,grade.S6 AS sgpa,result.S6 AS pass FROM grade,result where grade.REG_NO='$var1'and result.regno='$var1'
                            UNION
                        SELECT grade.REG_NO as RegNo,'S7' AS sem,grade.S7 AS sgpa, result.S7 AS pass FROM grade,result where grade.REG_NO='$var1'and result.regno='$var1'
                            UNION 
                        SELECT grade.REG_NO as RegNo,'S8' AS sem,grade.S8 AS sgpa,result.S8 AS pass FROM grade,result where grade.REG_NO='$var1'and result.regno='$var1'
                        ) as sub 
                        ORDER BY sem";
                    $_SESSION["sql"]= $sql;  
                    $sq2="SELECT * FROM information WHERE regno='$var1'";
                    $result=mysqli_query($conn,$sq2);
                    $s="SELECT MAX(SUBSTRING(pass,5,3)) as yr from ($sql) AS year ";
                    $resul=mysqli_query($conn,$s);
                    while($row=mysqli_fetch_assoc($result)){
                        echo "
                        <div><label>Name :   " . $row["name"] . "</label></div>
                        <div><label>Age :    " . $row["age"] . "</label></div>
                        <div><label>Sex :    " . $row["sex"] . "</label></div>
                        <div><label>REG ID : " . $row["regno"] . "</label></div>
                        <div><label>University :  " . $row["uty"] . "</label></div>
                        <div><label>Date Of Adm :" . $row["doa"] . "</label></div>
                        ";
                    }
                    $sqll="SELECT sem from ($sql) AS temp1 WHERE sgpa=0 ";
                    $results=mysqli_query($conn,$sqll);
                    $rowcounts=mysqli_num_rows($results);
                    while($row1=mysqli_fetch_assoc($resul))
                        {
                            if($rowcounts == 0)
                            {
                                echo "
                                <div><label>YearOfPass:20" . $row1["yr"] . "</label></div>
                                ";
                            }
                        }
                    ?>
            </div>
            <div class="btn">
                <button type="submit"><a href="print.php">Print</a></button>
            </div>
        </div>
        <div class="info neat" >
            <h2 id="hh">Report</h2>
            <table class="table">
                <thead class="tabhead">
                    <tr>
                        <th> SEMESTER </th>
                        <th> SGPA </th>
                        <th> MAX </th>
                        <th> MM & YY OF PASS </th>
                        <th> STATUS </th>
        
                    </tr>
                </thead>
                <tbody>
                        <?php
                    $result=mysqli_query($conn,$sql);
                    while($row=mysqli_fetch_assoc($result)){
                        $var2=$row["sem"];
                        if ($row["sgpa"])
                        {
                            echo "<tr>
                            <td>$var2</td>
                            <td>" . $row["sgpa"] . "</td>
                            <td>10</td>
                            <td>" . $row["pass"] . "</td>
                            <td> PASS </td>
                            </tr>
                            ";
                        }
                        else
                        {
                            echo "<tr>
                            <td><a href='update.php'>$var2</a></td>
                            <td>" . $row["sgpa"] . "</td>
                            <td>10</td>
                            <td>" . $row["pass"] . "</td>
                            <td>FAIL</td>
                            </tr>
                            ";
                        }
                        
                    }
                    $sql1="SELECT SUM(sgpa)/7 AS Total FROM ($sql) AS cgpa";
                    $result=mysqli_query($conn,$sql1);
                    $sq="SELECT sem from ($sql) AS temp1 WHERE sgpa=0 ";
                    $resul=mysqli_query($conn,$sq);
                    $rowcount=mysqli_num_rows($resul);
                    while($row=mysqli_fetch_assoc($result))
                    {
                        if($rowcount > 0)
                        {
                            echo "
                            <tr>
                            <td>GrandTotal</td>
                            <td>~~</td>
                            <td>~~ </td>
                            <td ColSpan=2 id='fail'>FAIL</td>
                            </tr>
                            ";
                        }
                        else{
                            echo "
                            <tr>
                            <td>GrandTotal</td>
                            <td>" . round($row["Total"],2) . "</td>
                            <td>10</td>
                            <td ColSpan=2 id='pass'>PASS</td>
                            </tr>
                            ";
                        }
                    }
        
                    ?>
                </tbody>
                </table>
                <div class="summ">
                    <?php
                    $sq3="SELECT sem from ($sql) AS semester WHERE sgpa=0 ";
                    $res=mysqli_query($conn,$sq3);
                    $rowcount=mysqli_num_rows($res);
                    if($rowcount > 0)
                    {
                        echo "SEMESTER TO BE CLEARED ";
                    }
                    while($row=mysqli_fetch_assoc($res))
                    {
                        $var22=$row["sem"];
                        echo "
                        <label><a href='update.php' >$var22</a></label>";
                    }
                    ?>
                </div>
                <?php
                  if(isset($_POST["find"])) {
                    $_SESSION["ktid"]=$_POST["search"];
                    echo"<script>window.location.href='dash.php';</script>";
                  }
                ?>
            <div class="bck">
                <button type="submit" ><a href="s.php" >Back</a></button>
            </div>
        </div>
    </div>
</body>
</html>
