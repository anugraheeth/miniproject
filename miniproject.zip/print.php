
<?php
        session_start();
        $var11=$_SESSION["ktid"];
        $var21=$_SESSION["sql"];
        require('vendor/autoload.php');
        if(substr($var11,0,3)=="KGR"){
            require_once "ktu.php";
        }
        else{
            require_once "cusat.php";
        }
        $sql="SELECT * FROM information WHERE regno='$var11'";
        $result=mysqli_query($conn,$sql);
        $sq="SELECT MAX(SUBSTRING(pass,5,3)) as yr from ($var21) AS year ";
         $resul=mysqli_query($conn,$sq);
        while($row=mysqli_fetch_assoc($result)){

            $name= $row["name"];
            $age= $row["age"];
            $sex= $row["sex"];
            $reg= $row["regno"];
            $uni= $row["uty"];
            $date= $row["doa"];
    
        }
        $sqll="SELECT sem from ($var21) AS count WHERE sgpa=0";
            $results=mysqli_query($conn,$sqll);
            $rowcounts=mysqli_num_rows($results);
        while($row1=mysqli_fetch_assoc($resul))
            {
                if($rowcounts == 0)
                {
                    
                    $y= $row1["yr"] ;
                }
            }

            $htm='<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Student Report</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        margin: 0;
                        padding: 0;
                    }
                    .container {
                        width: 210mm; /* A4 width */
                        height: 297mm; /* A4 height */
                        margin: 20px auto;
                        padding: 20px;
                        border: 1px solid #000;
                        box-sizing: border-box;
                    }
                    h1, h2 {
                        text-align: center;
                    }
                    .info {
                        margin:55px;
                        font-size:x-large;
                    }
                    .info span {
                        display: inline-block;
                        width: 200px;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1><u><b>College Of Engineering kidangoor</b></u></h1>
                    <br>
                    <h2>Student Report</h2>
                    <div class="info" >
                        <span>Name:</span>'. $name .'
                    </div>
                    <div class="info">
                        <span>Age:</span> '. $age .'
                    </div>
                    <div class="info">
                        <span>Sex:</span> '. $sex .'
                    </div>
                    <div class="info">
                        <span>Register Number:</span> '. $reg .'
                    </div>
                    <div class="info">
                        <span>University:</span> '. $uni .'
                    </div>
                    <div class="info">
                        <span>Date of Joining:</span> '. $date .'
                    </div>
                    <div class="info">
                        <span>Date of Pass Out:</span> 20'. $y .'
                    </div>
                </div>
            </body>
            </html>';
            $mpdf=new \Mpdf\Mpdf();
            $mpdf->WriteHTML($htm);
            $mpdf->output('result.pdf','i');
        ?>
 