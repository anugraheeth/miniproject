<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update</title>
    <link rel="stylesheet" href="logreg.css">
</head>
<body>
    <div class="header">
        <h2 class="logo">Grade Master</h2>
        <nav class="navigation">
            <a href="home.html">Home</a>
            <a href="about.html">About Us</a>
            <a href="dash.php">Back</a>
            <a href="logout.php">Log Out</a>
        </nav>
    </div>
    <div class="log" style="min-height: auto;">
        <?php
        session_start();
        if (!isset($_SESSION['user_authenticated'])) {
            header("Location: login.php");
            exit;
        }
        $var20=$_SESSION["ktid"];
        if(substr($var20,0,3)=="KGR"){
            require_once "ktu.php";
        }
        else{
            require_once "cusat.php";
        }
            if(isset($_POST["update"])){
                $codes=$_POST["sm"];
                $mark=$_POST["mark"];
                $yop=$_POST["year"];
                if($mark)
                {
                    $sql="UPDATE grade SET $codes='$mark' WHERE REG_NO='$var20'";
                    $pyr="UPDATE result SET $codes='$yop' WHERE regno='$var20'";
                    $result=mysqli_query($conn,$sql);
                    $resultss=mysqli_query($conn,$pyr);
                    if($result AND $resultss){
                        echo "updated successfully";
                    }
                    header('Location:dash.php');
                    exit;
                }
                else
                {
                    header('Location:update.php');  
                    exit;
                }
            }
            ?>
        <div class="txt">
            <h2 style="text-align:center;">Update Report</h2>
        </div>
        <form action="update.php" method="POST">
            <select name="sm" id="sm" style="background: transparent; padding: 2%;color: #8e05c2;font-weight:bolder;font-size:large">
            <?php
            session_start();
            $var20=$_SESSION["ktid"];
            $var21=$_SESSION["sql"];
            if(substr($var20,0,3)=="KGR"){
                require_once "ktu.php";
            }
            else{
                require_once "cusat.php";
            }
            $sql="SELECT sem from ($var21) AS temp3 where  sgpa=0";
            $result=mysqli_query($conn,$sql);
            while($row=mysqli_fetch_assoc($result)){
                echo "
                <option>" . $row["sem"] . "</option>
                ";
            }
            ?>
            </select>
            <div class="frme">
                <input type="text" name="mark" id="mark" placeholder="enter the marks " required>
            </div>
            <div class="frme">
                <input type="text" name="year" id="year" placeholder="enter the pass mm&yy " required >
            </div>
            <button type="submit" name="update">Update</button>
        </form>
        
    </div >
</body>
</html>
