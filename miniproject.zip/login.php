<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log In</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="logreg.css">
</head>
<body>
    <div class="header">
        <h2 class="logo">Grade Master</h2>
        <nav class="navigation">
            <a href="home.html">Home</a>
            <a href="about.html">About Us</a>
            <a href="login.php">Log In</a>
            <a href="register.php">Sign Up</a>
        </nav>
    </div>
    <div class="log">
        <div class="txt">
            <h2 style="text-align:center;">log in</h2>
        </div>
        <form action="login.php" method="POST">
            <div class="frme">
                <span class="icon"></span>
                <input id="email" type="email" name="email"  placeholder="email" required>
            </div>
            <div class="frme">
                <span class="icon"></span>
                <input id="name" type="password" name="password"  placeholder="password" required>
            </div>
            <div class="rp">
                <label ><input type="checkbox" name="rr" >Remember Me</label>
                <a href="#">Forgot Password</a>
            </div>
            <button type="submit" name="submit">login</button>
            <div class="reg">
                <p>Dont have an account <a href="register.php">Register</a></p>
            </div>
        </form>
        <script>
            document.getElementById("email").addEventListener("change",(eve)=>{
                document.getElementById("danger").textContent="";
            });
        </script>
        <?php
        if(isset($_POST["submit"])){
            session_start();
            $_SESSION['user_authenticated'] = true;
            $email = $_POST["email"];
            $pass=$_POST["password"];
            require_once "db.php";
            $sql="SELECT email,password FROM user where email='$email'";
            $result=mysqli_query($conn,$sql);
            $rowcount=mysqli_num_rows($result);
            $row=mysqli_fetch_assoc($result);
            if($rowcount > 0 AND $row["email"]==$email AND $row["password"]==$pass){
                echo"<script>window.location.href='s.php';</script>";
                        }
            else{
                echo "<div class='alert alert-danger' id='danger' style='margin-left: 75px;background:transparent;border:none'>INVALID EMAIL OR PASSWORD</div>";
            }
        }
        ?>
        
    </div>
</body>
</html>
