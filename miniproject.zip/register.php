<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="logreg.css">
 
</head>
<body>
    <div class="header">
        <h2 class="logo">Grade Master</h2>
        <nav class="navigation">
            <a href="home.html">Home</a>
            <a href="about.html">About Us</a>
            <a href="login.php">Log In</a>
            <a href="register.php">Sign Up</a>
        </nav>
    </div>
    <div class="log">
        
        <div class="txt">
            <h2 style="text-align:center;">Sign Up</h2>
        </div>
        <form action="register.php" method="POST">
            <div class="frme">
                <span class="icon"></span>
                <input type="text" name="fullname" id="name" placeholder="enter your name" required>
            </div>
            <div class="frme">
                <span class="icon"></span>
                <input type="text" name="dpt" id="dpt" placeholder="enter your department" required>
            </div>
            <div class="frme">
                <span class="icon"></span>
                <input type="email" name="email" id="email" placeholder="email" required>
            </div>
            <div class="frme">
                <span class="icon"></span>
                <input type="password" name="password" id="password" placeholder="password" required>
            </div>
            <div class="frme">
                <span class="icon"></span>
                <input type="password" name="cpassword" id="cpassword" placeholder=" conform password" required>
            </div>
            <button type="submit" name="submit">Sign Up</button>
            <div class="reg">
                <p>Already a User <a href="login.php">Log In</a></p>
            </div>
        </form>
        <?php
        if (isset($_POST["submit"])){
            $fullName = $_POST["fullname"];
            $email = $_POST["email"];
            $password = $_POST["password"];
            $passwordr = $_POST["cpassword"];
            $passwordHash = password_hash($password,PASSWORD_DEFAULT);
            $error = array();
            if(empty($fullName) OR empty($email) OR empty($password) OR empty($passwordr))
            {
                array_push($error,"All fields are required");
            }
            if(!filter_var($email,FILTER_VALIDATE_EMAIL))
            {
                array_push($error,"Email is not valid");
            }
            if(strlen($password) < 8)
            {
                array_push($error,"Password must be atlest 8 characters");
            }
            if($password !== $passwordr)
            {
                array_push($error,"Password doesnot match");
            }
            require_once "db.php";
            $sql="SELECT * FROM user where email='$email'";
            $result=mysqli_query($conn,$sql);
            $rowcount=mysqli_num_rows($result);
            if($rowcount > 0)
            {
                array_push($error,"Email already exist");
            }
            if(count($error) > 0)
            {
                foreach ($error as $err) {
                    echo "<div class='alert alert-danger' id='danger' style='text-align:center;background:transparent;border:none'>$err</div>";
                }
            }
            else
            {
                require_once "db.php";
                $sql = "INSERT INTO user (fullname,email,password) VALUES (?,?,?)";
                $stmt = mysqli_stmt_init($conn);
                $prepareStmt = mysqli_stmt_prepare($stmt,$sql);
                if ($prepareStmt)
                {
                  mysqli_stmt_bind_param($stmt,"sss",$fullName,$email,$password);
                  mysqli_stmt_execute($stmt);
                  echo "<div class='alert alert-danger' id='danger' style='text-align:center;background:transparent;border:none;color:green'>You have registered successfully</div>";
                }
                else
                {
                    die("something went wrong");
                }
                echo"<script>window.location.href='login.php';</script>";
            }

        }
        ?>
        <script>
            document.getElementById("email").addEventListener("change",(eve)=>{
                document.getElementById("danger").textContent="";
            });
        </script>
    </div>
</body>
</html>
