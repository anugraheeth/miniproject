<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search</title>
    <link rel="stylesheet" href="logreg.css">
</head>
<body>
    <div class="header">
        <h2 class="logo">Grade Master</h2>
        <nav class="navigation">
            <a href="home.html">Home</a>
            <a href="about.html">About Us</a>
            <a href="logout.php">Log Out</a>
            
        </nav>
    </div>
    <div class="log" style="min-height: auto;">
        <div class="txt">
            <h2 style="text-align:center;">Find Report</h2>
        </div>
        <form action="s.php" method="POST">
            <div class="frme">
                <input type="text" name="ktuid" id="ktuid" placeholder="enter register number " >
            </div>
            <div class="frme">
                <input type="text" name="year" id="year" placeholder="enter batch year to view all data " >
            </div>
            <button type="submit" name="submit">Find</button>
        </form>
        <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const id = document.getElementById('ktuid');
                    const btc = document.getElementById('year');

                    function handleInputChange(event) {
                        if (event.target === id && id.value.trim() !== '') {
                            btc.disabled = true;
                        } else if (event.target === btc && btc.value.trim() !== '') {
                            id.disabled = true;
                        } else {
                            id.disabled = false;
                            btc.disabled = false;
                        }
                    }

                    id.addEventListener('input', handleInputChange);
                    btc.addEventListener('input', handleInputChange);
                
                    id.addEventListener('keydown', function(event) {
                        if (event.key === 'Backspace' && id.value.trim() === '') {
                            btc.disabled = false;
                        }
                    });

                    btc.addEventListener('keydown', function(event) {
                        if (event.key === 'Backspace' && btc.value.trim() === '') {
                            id.disabled = false;
                        }
                    });
                });
                
        </script>
        <?php
        error_reporting(E_ERROR | E_PARSE);
        session_start();
        if (!isset($_SESSION['user_authenticated'])) {
             header("Location: login.php");
            exit;
        }
        if(isset($_POST["submit"])){
            $id='';
            $btc='';
            $id = $_POST["ktuid"];
            $btc = $_POST["year"]; 
            if($id!='' && $btc==''){
                session_start();
                $_SESSION["ktid"]= $id;
                if(substr($id,0,3)=="KGR"){
                    require_once "ktu.php";
                }
                else{
                    require_once "cusat.php";
                }
                $sql="SELECT regno FROM information where regno='$id'";
                $result=mysqli_query($conn,$sql);
                $rowcount=$result->num_rows;
                if($rowcount>0){
                    header('Location: dash.php');
                    exit;
                }
                else{
                    echo "<div class='alert alert-danger'  id='danger' style='text-align:center'>PLEASE ENTER A  VALID ID </div>";
                }
            }
            else if($id=='' && $btc!=''){
                session_start();
                $_SESSION["batch"]= $btc;
                if($btc<2015){
                    require_once "cusat.php";
                }
                else{
                    require_once "ktu.php";
                }
                $sqli="SELECT batch FROM information where batch='$btc'";
                $resulti=mysqli_query($conn,$sqli);
                $rowcount=$resulti->num_rows;
                if($rowcount>0){
                    header('Location: pagination.php');
                    exit;
                }
                else{
                    echo "<div class='alert alert-danger'  id='danger' style='text-align:center'>BATCH NOT FOUND </div>";
                }
            }
        }
        ?>
    </div>
</body>
</html>
