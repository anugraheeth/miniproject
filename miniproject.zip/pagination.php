<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dash Board </title>
    <script src="https://unpkg.com/phosphor-icons"></script>
    <link rel="stylesheet" href="dash.css">
</head>
<body>
<?php
session_start();
if (!isset($_SESSION['user_authenticated'])) {
    header("Location: login.php");
    exit;
}
$batch=$_SESSION["batch"];
?>
        <div class="header">
        <h2 class="logo">Grade Master</h2>
        <nav class="navigation">
            <form method="POST">
                <div class="search">
                    <input type="text" class="search-box" placeholder="Search..." name="search" required>
                    <button class="search-btn" name="find"><i class="ph-magnifying-glass-bold"></i></button>
                </div>
            </form>
            <a href="logout.php">Log Out</a>
        </nav>
    </div>
    <div class="txt">
        <h2 style="text-align: center;">Batch<?php echo" $batch " ?></h2>
    </div>
    <div class="container " style="margin-left:22.5%">
        <div class="scroll" id="scroll">
            <table class="table">
                <thead class="scrollhead">
                    <tr>
                        <th> REG NO </th>
                        <th> NAME </th>
                        <th> UNIVERSITY </th>
                        <th> STATUS </th>
        
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if($batch<2015){
                        require_once "cusat.php";
                    }
                    else{
                        require_once "ktu.php";
                    }
                    $sql="SELECT regno,name,uty from information where batch='$batch'";
                    $result=mysqli_query($conn,$sql);
                    while($row=mysqli_fetch_assoc($result)){
                        $id= $row["regno"];
                        $status="SELECT sgpa FROM (
                            SELECT 'S1S2' AS sem,grade.S1S2 AS sgpa FROM grade,result where grade.REG_NO='$id'and result.regno='$id'
                            UNION
                            SELECT 'S3' AS sem,grade.S3 AS sgpa FROM grade,result where grade.REG_NO='$id'and result.regno='$id'
                            UNION
                            SELECT 'S4' AS sem,grade.S4 AS sgpa FROM grade,result where grade.REG_NO='$id'and result.regno='$id'
                            UNION
                            SELECT 'S5' AS sem,grade.S5 AS sgpa FROM grade,result where grade.REG_NO='$id'and result.regno='$id'
                            UNION
                            SELECT 'S6' AS sem,grade.S6 AS sgpa FROM grade,result where grade.REG_NO='$id'and result.regno='$id'
                            UNION
                            SELECT 'S7' AS sem,grade.S7 AS sgpa FROM grade,result where grade.REG_NO='$id'and result.regno='$id'
                            UNION
                            SELECT 'S8' AS sem,grade.S8 AS sgpa FROM grade,result where grade.REG_NO='$id'and result.regno='$id')
                            AS sub where sgpa=0
                            order by sem";
                        $res=mysqli_query($conn,$status);
                        $rowcount=mysqli_num_rows($res);
                        if($rowcount>0){
                            
                            echo "<tr>
                                    <td id='fail'><form  method='POST'><button  name='fid' type='submit' class='fbt' value=" . $row["regno"] . ">" . $row["regno"] . "</button></form></td>
                                    <td id='fail'>" . $row["name"] . "</td>
                                    <td id='fail'>" . $row["uty"] . "</td>
                                    <td id='fail'>FAIL</td>

                                </tr>";
                        }
                        else{
                           
                            echo "<tr>
                                    <td>" . $row["regno"] . "</td>
                                    <td>" . $row["name"] . "</td>
                                    <td>" . $row["uty"] . "</td>
                                    <td>PASS</td>
                                </tr>";
                        }
                    } 
                    
                    ?>
                </tbody>
                </table>
                <?php
                $idss=0;
                  if(isset($_POST["fid"])) {
                    $_SESSION["ktid"]=$_POST["fid"];
                    $idss=1;
                  }

                  if(isset($_POST["find"])) {
                    $_SESSION["batch"]=$_POST["search"];
                    echo"<script>window.location.href='pagination.php';</script>";
                  }

                  if($idss==1)
                  {
                    echo"<script>window.location.href='dash.php';</script>";
                  }
                ?>
                <div class="bck">
                    <button type="submit" ><a href="s.php" >Back</a></button>
                </div>
        </div>
    </div>
</body>
</html>