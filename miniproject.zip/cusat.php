<?php
$hostname='localhost';
$dbuser='root';
$dbPassword='';
$dbName='cusat';
$conn=mysqli_connect($hostname, $dbuser, $dbPassword, $dbName);
if(!$conn){
    die("Something went worng");
}
?>